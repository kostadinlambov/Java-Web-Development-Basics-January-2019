package panda.domain.entities;

public enum Status {
    
    Pending, Shipped, Delivered, Acquired;
}
