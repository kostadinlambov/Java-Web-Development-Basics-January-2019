//package app.validations;
//
//import org.springframework.stereotype.Component;
//
//import javax.validation.Constraint;
//import javax.validation.Payload;
//import java.lang.annotation.ElementType;
//import java.lang.annotation.Retention;
//import java.lang.annotation.RetentionPolicy;
//import java.lang.annotation.Target;
//
//@Component
//@Constraint(validatedBy = UniqueEmailValidator.class)
//@Target({ElementType.FIELD, ElementType.METHOD})
//@Retention(RetentionPolicy.RUNTIME)
//public @interface UniqueEmail {
//    String message() default "E-mail already exists.";
//
//    Class<?>[] groups() default {};
//
//    Class<? extends Payload>[] payload()default {};
//}
