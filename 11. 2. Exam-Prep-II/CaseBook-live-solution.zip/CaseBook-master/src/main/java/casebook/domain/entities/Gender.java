package casebook.domain.entities;

public enum Gender {

    Female, Male;
}
